
#pragma once
#include <string>


enum DegreeProgram { SECURITY, NETWORK, SOFTWARE };

static const std::string degreeProgramStrings[] = { "SECURITY", "NETWORK", "SOFTWARE" };