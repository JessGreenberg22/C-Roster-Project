#pragma once
#include <iostream>
#include <iomanip>
#include "degree.h"
using namespace std;


class Student {

public:
	const static int DaystoCompleteARRAY_SIZE = 3;

public:
	string studentID;
	string firstName;
	string lastName;
	string email;
	int age;
	int daysArray[DaystoCompleteARRAY_SIZE];
	DegreeProgram degreeProgram;

public:
	Student();
	Student(string studentID, string firstName, string lastName, string email, int age, int days[], DegreeProgram degreeProgram);
	~Student();


	string getstudentID();
	string getFirstName();
	string getLastName();
	string getEmail();
	int getAge();
	int* getDaystocomplete();
	DegreeProgram getDegreeProgram();

	void setStudentID(string sID);
	void setFirstName(string fName);
	void setLastName(string lName);
	void setEmail(string email);
	void setAge(int age);
	void setDays(int days[]);
	void setDegreeProgram(DegreeProgram degreeProgram);

	bool hasInvalidEmail();
	double averageDaysInCourse();

	static void printHeaders();

	void print();
};